<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <style>
    @page {
        width: 5.5cm;
    }
    </style>
</head>

<body onload="window.print();">
    <center>
        <h4>Halo Ini Novinaldi</h4>
        <table>
            <thead>
                <tr>
                    <th>No</th>
                    <th>Item</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>1</td>
                    <td>Cappucino</td>
                </tr>
            </tbody>
        </table>
    </center>
</body>

</html>