<div class="row">
    <div class="col-lg-12">
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">
                    Anda Login Sebagai Super Admin
                </h6>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="alert alert-info">
                        <ul>
                            <li>Anda dapat menghapus data transaksi yang ada dengan mengklik menu Utility.</li>
                            <li>
                                Silahkan Tambahkan Toko pada menu manajemen toko
                            </li>
                            <li>Silahkan tambahkan user yang memiliki akses ke toko</li>
                        </ul>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>